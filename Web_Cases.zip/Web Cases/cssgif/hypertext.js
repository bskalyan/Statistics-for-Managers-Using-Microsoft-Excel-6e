// JavaScript Document
function htpopup(hlink,type) {
obj=document.getElementById(hlink);
if (type == 'simple') {
	NewWin=window.open('','Popup','menubar=yes,toolbar=no,status=no,width=600,height=150,resizeable=yes,scrollbars=yes');
}
else {
NewWin=window.open('','Popup','menubar=yes,toolbar=no,status=no,width=600,height=300,resizeable=yes,scrollbars=yes');
}
NewWin.document.write('<HTML><script language="JavaScript 1.5" type="text/javascript" src="hypertext.js"></script><body>');
NewWin.document.write(obj.innerHTML);
NewWin.document.write('</Body></HTML>');
}
function showIt(hlink,type) {
obj=document.getElementById(hlink);
visible=(obj.style.display!="none")
if (visible) {
	obj.style.display="none";
} else {
	obj.style.display="block";
}
}
function revealIt(hlink) {
obj=document.getElementById(hlink);
visible=(obj.style.display!="none")
if (visible) {
	obj.style.display="none";
} else {
	obj.style.display="block";
}
}
function Toggle(item) {
   obj=document.getElementById(item);
   visible=(obj.style.display!="none")
   key=document.getElementById("x" + item);
   if (visible) {
     obj.style.display="none";
     key.innerHTML="[+]";
   } else {
      obj.style.display="block";
      key.innerHTML="[-]";
   }
}
function MM_popupMsg(msg) { 
  alert(msg);
}
